import os
import random
import platform
import time
import getpass


# variables
devmode = False
fac = False
cpu = platform.processor()
gpu = "uknown"

start = time.time()

# Function to get the script uptime
def uptime():
    # Calculate the elapsed time in seconds
    elapsed = time.time() - start
    return int(elapsed)



os.system("clear")
username = input("New GasolineOS username: ")
os.system("clear")

print(f"Welcome to GasolineOS, {username}!")
print("=============================================================================================================================")
print("")
print("Terminal.ose")
print("")
print("Notepad.ose")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")

while True:
    print("")
    print("=============================================================================================================================")
    print("What would you like to do?")
    commandline = input(f"{username}~$: ")

    # commands

    if commandline == "help":
        print("List of GasolineOS commands")
        print("-=========================-")
        print("open - opens any file with the .ose format")
        print("open -external - opens files that don't have a .ose format")
        print("sysinfo - the GasolineOS neofetch")
        print("version - displays the OS version")
        print("clear - clears the screen")
        print("download - downloads an .xse, see download -help for help")

    if commandline == "version":
        print("GasolineOS Version 0.1")
    
    if commandline == "clear":
        os.system("clear")

    if commandline == "desktop" and fac == True:
        print("=============================================================================================================================")
        print("")
        print("Terminal.ose")
        print("")
        print("Notepad.ose")
        print("")
        print("Flip A Coin.xse")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        
    if commandline == "desktop" and fac == False:
        print("=============================================================================================================================")
        print("")
        print("Terminal.ose")
        print("")
        print("Notepad.ose")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
        print("")
    
    if commandline == "download -help":
        print("available .xse files")
        print("-==================-")
        print("FlipACoin.xse")
        print("")

    if commandline == "download -external FlipACoin.xse":
        print("Downloading...")
        fac = True

    if commandline == "Dime":
        print("You found a secret!")

    if fac == True and commandline == "open -external FlipACoin.xse":
        print("Welcome to flip a coin!")
        print("this little program will tell you heads or tails for you.")
        os.system("clear")
        print("Flipping a coin...")
        time.sleep(1)
        headsortails = random.randint(1, 2)
        if headsortails == 1:
            print("Heads!")
        if headsortails == 2:
            print("Tails!")

    if commandline == "TheBerlinWall":
        devmode = True

    if commandline == "sysinfo" and fac == False and devmode == False:
        print(f"                 _   OS: Gasoline 0.1")
        print(f"               /  /  Host: {username}")
        print(f"    _______   /  /   Kernel: Python")
        print(f"   / |_____||/  /    Uptime: {uptime()} seconds")
        print(f"  /           \/     Packages: 0")
        print(f"  | \        / |     Shell: CNB")
        print(f"  |  \      /  |     Resolution: uknown")
        print(f"  |    ____    |     Terminal: GasolineOS Terminal V0.1")
        print(f"  |  /      \  |     CPU: {cpu}")
        print(f"  | /        \ |     GPU: {gpu}")
        print(f"  |____________|     Memory: unknown")

    if commandline == "sysinfo" and fac == True and devmode == False:
        print(f"                 _   OS: Gasoline 0.1")
        print(f"               /  /  Host: {username}")
        print(f"    _______   /  /   Kernel: Python")
        print(f"   / |_____||/  /    Uptime: {uptime()} seconds")
        print(f"  /           \/     Packages: 1")
        print(f"  | \        / |     Shell: CNB")
        print(f"  |  \      /  |     Resolution: uknown")
        print(f"  |    ____    |     Terminal: GasolineOS Terminal V0.1")
        print(f"  |  /      \  |     CPU: {cpu}")
        print(f"  | /        \ |     GPU: {gpu}")
        print(f"  |____________|     Memory: unknown")

    if commandline == "sysinfo" and devmode == True:
        print(f"                 _   OS: Gasoline 0.1")
        print(f"               /  /  Host: {username}")
        print(f"    _______   /  /   Kernel: Python - LOL THERE IS NO KERNEL")
        print(f"   / |_____||/  /    Uptime: {uptime()} seconds")
        print(f"  /           \/     Packages: yada yada, its FlipACoin we know :/")
        print(f"  | \        / |     Shell: CNB - CMD Not Batch / Bash")
        print(f"  |  \      /  |     Resolution: uknown - Idk how to get the thing for it lol")
        print(f"  |    ____    |     Terminal: GasolineOS Terminal V0.1")
        print(f"  |  /      \  |     CPU: {cpu}")
        print(f"  | /        \ |     GPU: {gpu} - LOL")
        print(f"  |____________|     Memory: unknown - fuck you")

    